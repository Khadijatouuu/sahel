<?php
require_once ('settings/bdd.inc.php');
require_once ('settings/init.inc.php');
include_once 'includes/header.inc.php';
?>
<div class="span8">
    <form action="articles.php" method="post" enctype="multipart/form-data" id="form_article" name="form_article">
        <div class="clearfix">
            <label for="titre">Titre</label>
            <div class="input"><input type="text" name="titre" id="titre" value=""></div>
        </div>
        
        <div class="clearfix">
            <label for="titre">Texte</label>
            <div class="input"><textarea name="texte" id="texte"></textarea></div>
        </div>
        
        <div class="clearfix">
            <label for="image">Image</label>
            <div class="input"><input type="file" name="image" id="image"></div>
        </div>
        
        <div class="clearfix">
            <label for="publie">Publié</label>
            <div class="input"><input type="checkbox" name="publie" id="publie"></div>
        </div>
        
        <div class="form-actions">
            <input type="submit" name="ajouter" value="ajouter" class="btn btn-large btn-primary">
        </div>
    </form>
</div>
<?php
include_once 'includes/menu.inc.php';
include_once 'includes/footer.inc.php';
?>

