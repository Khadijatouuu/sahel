<?php

    <?phpvcf
require_once'settings/init.inc.php';
require_once'settings/bdd.inc.php';
include_once'includes/header.inc.php';
<div class="span8">
           <?php
    foreach ($tab_article as $value){
        ?>
         <h2><?php echo $value['titre'] ?></h2>
   
   
    
 <?php
    }
    ?>
<?php
include_once'includes/menu.inc.php';
include_once'includes/footer.inc.php';
?>


